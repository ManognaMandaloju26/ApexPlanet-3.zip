async function getJoke() {
  const jokeEl = document.getElementById("joke");

  jokeEl.innerText = "Fetching joke...";

  try {
    const response = await fetch("https://icanhazdadjoke.com/", {
      headers: { Accept: "application/json" }
    });

    if (!response.ok) {
      throw new Error("Joke fetch failed");
    }

    const data = await response.json();
    jokeEl.innerText = data.joke;
  } catch (error) {
    jokeEl.innerText = "Oops! Couldn't load joke.";
    console.error(error);
  }
}

// Load first joke when page opens
getJoke();