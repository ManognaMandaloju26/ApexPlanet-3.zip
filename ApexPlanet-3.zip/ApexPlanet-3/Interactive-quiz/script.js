const questions = [
  {
    q: "What is 2 + 2?",
    options: ["3", "4", "5", "6"],
    answer: "4"
  },
  {
    q: "Capital of India?",
    options: ["Mumbai", "Delhi", "Kolkata", "Chennai"],
    answer: "Delhi"
  },
  {
    q: "How many players are there in a football (soccer) team on the field?",
    options: ["9", "10", "11", "12"],
    answer: "11"
  }
];

let current = 0;
let selectedOption = false;

function showQuestion() {
  const q = questions[current];
  document.getElementById("question").innerText = q.q;

  const optionsList = document.getElementById("options");
  optionsList.innerHTML = "";
  selectedOption = false;

  q.options.forEach(opt => {
    const li = document.createElement("li");
    li.innerText = opt;
    li.classList.add("option");
    li.onclick = () => selectAnswer(li, opt);
    optionsList.appendChild(li);
  });

  document.getElementById("next-btn").innerText = "Next";
  document.getElementById("next-btn").disabled = false;
}

function selectAnswer(element, selectedText) {
  const correctAnswer = questions[current].answer;

  document.querySelectorAll(".option").forEach(opt => {
    opt.classList.remove("correct", "wrong", "selected");
  });

  element.classList.add("selected");

  if (selectedText === correctAnswer) {
    element.classList.add("correct");
  } else {
    element.classList.add("wrong");
  }

  selectedOption = true;
}

function nextQuestion() {
  if (!selectedOption) {
    alert("Please select an answer before continuing.");
    return;
  }

  current++;
  if (current < questions.length) {
    showQuestion();
  } else {
    document.getElementById("question").innerText = "🎉 Quiz Completed!";
    document.getElementById("options").innerHTML = "";
    document.getElementById("next-btn").innerText = "Restart";
    document.getElementById("next-btn").onclick = restartQuiz;
  }
}

function restartQuiz() {
  current = 0;
  showQuestion();
  document.getElementById("next-btn").onclick = nextQuestion;
}

showQuestion();